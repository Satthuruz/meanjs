# ngTable ES5 Demo App

## Overview

* Loads `ng-table` on to the page using a global script tag
* Application code written in ECMAScript 5

## Running sample App

1. If you haven't already done so: `npm run setup`
2. `cd demo-apps/es5` (this directory)
3. `npm start`
    * runs `http-server` to serve this app's index.html