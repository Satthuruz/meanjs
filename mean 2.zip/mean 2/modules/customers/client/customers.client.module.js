(function (app) {
  'use strict';

  app.registerModule('customers');
}(ApplicationConfiguration));
